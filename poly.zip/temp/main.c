/*-------------------
 * Name = Snehal Sanjay Shinde
 * Class = Div -2 Batch = S5 
 * MIS NO = 142103013
 * E-mail = shindess21.comp@coep.ac.in
 * Github = https://github.com/scarlet-speedster2
 * DSA  Assignment NO 4
 *
 * 
*/


#include<stdio.h>
#include<stdlib.h>
#include"poly.h"

	

int main()
{
    Node *poly1,*poly2,*poly ;
    
    init(&poly1);
    init(&poly2);
    init(&poly);

    char p1[] = "6x4+5x3+2x2"; 
    char p2[] = "7x5+2x3"; 
    int p1_len;
    int p2_len;

    p1_len = sizeof(p1)/sizeof(char);
    p2_len = sizeof(p2)/sizeof(char);


    initPolynomial(p1,p1_len,&poly1);
    initPolynomial(p2,p2_len,&poly2);


    printf("1st Number: ");
    displayPolynomial(poly1);

    printf("\n2nd Number: ");
    displayPolynomial(poly2);

    poly = (struct Node*)malloc(sizeof(struct Node));

    // Function add two polynomial numbers
    addPolynomial(poly1, poly2, poly);

    // Display resultant List
    printf("\nAddition of polynomials: ");
    displayPolynomial(poly);
    printf("\n");

    return 0;
}
