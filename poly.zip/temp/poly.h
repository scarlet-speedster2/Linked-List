/*-------------------
 * Name = Snehal Sanjay Shinde
 * Class = Div -2 Batch = S5 
 * MIS NO = 142103013
 * E-mail = shindess21.comp@coep.ac.in
 * Github = https://github.com/scarlet-speedster2
 * DSA  Assignment NO 4
 *
 * 
*/



typedef struct Node {
    int coeff;
    int pow;
    struct Node* next;
}Node;


void initPolynomial(char s[],int len, Node** temp);

void addPolynomial(Node* poly1, Node* poly2, Node* poly);

void displayPolynomial(Node* node);

void init(Node** p);
