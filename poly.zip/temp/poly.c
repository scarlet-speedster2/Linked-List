/*-------------------
 * Name = Snehal Sanjay Shinde
 * Class = Div -2 Batch = S5 
 * MIS NO = 142103013
 * E-mail = shindess21.comp@coep.ac.in
 * Github = https://github.com/scarlet-speedster2
 * DSA  Assignment NO 4
 *
 * 
*/

#include<stdio.h>
#include<stdlib.h>
#include"poly.h"


void initPolynomial(char s[],int len, Node** temp)
{
    
    int i = 0;
    for(i =0;i<len;i+=4){
	    
	    int x = (int)s[i];
	    x -=48;
	    int y = (int)s[i+2];
	    y -=48;

    Node *r, *z;

    z = *temp;
    if (z == NULL) {
        r = (Node*)malloc(sizeof(Node));
        r->coeff = x;
        r->pow = y;
        *temp = r;
        r->next = (Node*)malloc(sizeof(Node));
        r = r->next;
        r->next = NULL;
    }
    else {
        r->coeff = x;
        r->pow = y;
        r->next = (Node*)malloc(sizeof(Node));
        r = r->next;
        r->next = NULL;
    }
    }
}

void addPolynomial(Node* poly1, Node* poly2,
             Node* poly)
{
    while (poly1->next && poly2->next) {
        if (poly1->pow > poly2->pow) {
            poly->pow = poly1->pow;
            poly->coeff = poly1->coeff;
            poly1 = poly1->next;
        }

        else if (poly1->pow < poly2->pow) {
            poly->pow = poly2->pow;
            poly->coeff = poly2->coeff;
            poly2 = poly2->next;
        }

        // If power of both polynomial numbers is same then
        else {
            poly->pow = poly1->pow;
            poly->coeff = poly1->coeff + poly2->coeff;
            poly1 = poly1->next;
            poly2 = poly2->next;
        }

        // Dynamically create new node
        poly->next
            = (Node*)malloc(sizeof(Node));
        poly = poly->next;
        poly->next = NULL;
    }
    while (poly1->next || poly2->next) {
        if (poly1->next) {
            poly->pow = poly1->pow;
            poly->coeff = poly1->coeff;
            poly1 = poly1->next;
        }
        if (poly2->next) {
            poly->pow = poly2->pow;
            poly->coeff = poly2->coeff;
            poly2 = poly2->next;
        }
        poly->next
            = (Node*)malloc(sizeof(Node));
        poly = poly->next;
        poly->next = NULL;
    }
}

void displayPolynomial(Node* node)
{
    while (node->next != NULL) {
        printf("%dx^%d", node->coeff, node->pow);
        node = node->next;
        if (node->coeff >= 0) {
            if (node->next != NULL)
                printf("+");
        }
    }
}

void init(Node** p){
	*p = NULL;
	return;
}
